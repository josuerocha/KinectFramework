#!/bin/sh
#SCRIPT PARA CORRIGIR FALHA DE CRIACAO DE CONEXAO COM MOTOR NO OPENNI
git clone https://github.com/OpenNI/OpenNI.git
cd OpenNI
git checkout unstable
cp ../files/XnUSBLinux.cpp Source/OpenNI/Linux
cd Platform/Linux/CreateRedist
chmod +x RedistMaker
./RedistMaker
cd ../Redist/OpenNI-Bin-Dev-Linux-x64-v1.5.8.5/
sudo ./install.sh
cd ../../../../../..
